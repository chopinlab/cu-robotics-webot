from controller import Supervisor
import numpy as np
import matplotlib.pyplot as plt
from scipy import signal

# --- Constants and Configuration ---
# Maximum speed for the robot's wheels
MAX_ROBOT_SPEED = 6.28

# Proximity threshold for considering a waypoint reached (meters)
WAYPOINT_PROXIMITY_THRESHOLD = 0.32

ANGULAR_GAIN = 5
LINEAR_GAIN = 3

# World dimensions for map conversion
WORLD_WIDTH_METERS = 4.0
WORLD_HEIGHT_METERS = 6.0

# Initial robot pose
INITIAL_ROBOT_X = -0.300
INITIAL_ROBOT_Y = 0.425
INITIAL_ROBOT_ORIENTATION_RAD = 0.0

# Waypoints the robot will follow in sequence
NAVIGATION_WAYPOINTS = [
    (0.461, -0.119), (0.80, -0.92), (0.34, -3.13), (0.00 , -3.2),
    (-1.33, -3.39), (-1.51, -3.42), (-1.71, -1.47),
    (-1.41, 0.38), (0, 0)
]
# --- Helper Functions ---
def world_to_map_coordinates(world_x, world_y, map_shape, world_dimensions):

    map_width, map_height = map_shape
    world_width, world_height = world_dimensions

    pixel_x = int((world_x + 2.5) * map_width / world_width)
    pixel_y = int(-(world_y - 2) * map_height / world_height)

    # Clamp pixel coordinates to ensure they are within map boundaries
    pixel_x = min(pixel_x, (map_width - 1))
    pixel_y = min(pixel_y, (map_height - 1))
    pixel_x = max(pixel_x, 0)
    pixel_y = max(pixel_y, 0)

    return (pixel_x, pixel_y)

def normalize_angle_rad(angle_radians):

    return (angle_radians + np.pi) % (2 * np.pi) - np.pi

supervisor_robot = Supervisor()

simulation_time_step = int(supervisor_robot.getBasicTimeStep())

# Get motor devices and set them to infinite position control;
left_motor = supervisor_robot.getDevice('wheel_left_joint')
right_motor = supervisor_robot.getDevice('wheel_right_joint')
left_motor.setPosition(float('inf'))
right_motor.setPosition(float('inf'))

# Get and enable lidar sensor
lidar_sensor = supervisor_robot.getDevice('Hokuyo URG-04LX-UG01')
lidar_sensor.enable(simulation_time_step)
lidar_sensor.enablePointCloud() 

# Get display device GPS and Compass sensors for robot
robot_display = supervisor_robot.getDevice('display')
gps_sensor = supervisor_robot.getDevice('gps')
gps_sensor.enable(simulation_time_step)
compass_sensor = supervisor_robot.getDevice('compass')
compass_sensor.enable(simulation_time_step)

# Get handle to the target marker node and its translation/rotation fields
target_marker_node = supervisor_robot.getFromDef("marker")
target_marker_translation_field = target_marker_node.getField('translation')
target_marker_rotation_field = target_marker_node.getField('rotation')

# Get handle to the robot node and its translation/rotation fields
robot_node = supervisor_robot.getFromDef("tiago_lite")
robot_translation_field = robot_node.getField('translation')
robot_rotation_field = robot_node.getField('rotation')

lidar_original_field_of_view_degrees = 240.0
lidar_step_angle_degrees = 0.36 

# Calculate the full resolution
lidar_original_resolution = round(lidar_original_field_of_view_degrees / lidar_step_angle_degrees)

# Active resolution
lidar_active_resolution = lidar_original_resolution - 80 - 80
lidar_active_field_of_view_degrees = lidar_active_resolution * lidar_step_angle_degrees

# Get lidar's offset from the robot's center
lidar_node = supervisor_robot.getFromDef("LIDAR")
lidar_x_offset_meters = lidar_node.getField('translation').getSFVec3f()[0]
lidar_y_offset_meters = lidar_node.getField('translation').getSFVec3f()[1]

# Pre-calculate angles for each lidar ray
lidar_scan_angles_rad = np.linspace(
    lidar_active_field_of_view_degrees / 2 / 180 * np.pi,
    -lidar_active_field_of_view_degrees / 2 / 180 * np.pi,
    lidar_active_resolution
)

# Set the robot's initial position and orientation
robot_translation_field.setSFVec3f([INITIAL_ROBOT_X, INITIAL_ROBOT_Y, 0.15])
robot_rotation_field.setSFRotation([0, 0, 1, INITIAL_ROBOT_ORIENTATION_RAD])

current_waypoint_index = 0
navigation_round_count = 0 

occupancy_grid_map = np.zeros((robot_display.getWidth(), robot_display.getHeight()))
convolution_kernel = np.ones((30, 30)) if occupancy_grid_map.shape == (200, 300) else np.ones((60, 60))

# --- Main Simulation Loop ---
while supervisor_robot.step(simulation_time_step) != -1:
    robot_x_world = gps_sensor.getValues()[0]
    robot_y_world = gps_sensor.getValues()[1]
    robot_orientation_rad = np.arctan2(compass_sensor.getValues()[0],
                                       compass_sensor.getValues()[1])
                                       
    # Update the target marker's position if there are still waypoints to visit
    if current_waypoint_index < len(NAVIGATION_WAYPOINTS):
        target_marker_translation_field.setSFVec3f([*NAVIGATION_WAYPOINTS[current_waypoint_index], 0])
        target_marker_rotation_field.setSFRotation([0, 0, 1, 0]) # Keep marker upright

        # Calculate polar coordinates (distance and angle) from robot to current waypoint
        distance_to_waypoint = np.sqrt(
            (robot_x_world - NAVIGATION_WAYPOINTS[current_waypoint_index][0])**2 +
            (robot_y_world - NAVIGATION_WAYPOINTS[current_waypoint_index][1])**2
        )
        angle_to_waypoint = np.arctan2(
            NAVIGATION_WAYPOINTS[current_waypoint_index][1] - robot_y_world,
            NAVIGATION_WAYPOINTS[current_waypoint_index][0] - robot_x_world
        ) - robot_orientation_rad
        angle_to_waypoint = normalize_angle_rad(angle_to_waypoint) # Normalize angle to [-pi, pi]

    # Check if the robot has reached the current waypoint and advance to the next
    if distance_to_waypoint < WAYPOINT_PROXIMITY_THRESHOLD:
        if navigation_round_count == 0: 
            current_waypoint_index += 1
            if current_waypoint_index >= len(NAVIGATION_WAYPOINTS):
                navigation_round_count += 1 
        elif navigation_round_count == 1: 
            current_waypoint_index -= 1
            if current_waypoint_index < 0:
                navigation_round_count += 1

    # Create a 3x3 transformation matrix from robot frame to world frame
    robot_to_world_transform_matrix = np.array([
        [np.cos(robot_orientation_rad), -np.sin(robot_orientation_rad), robot_x_world],
        [np.sin(robot_orientation_rad),  np.cos(robot_orientation_rad), robot_y_world],
        [0, 0, 1]
    ])

    lidar_ranges = np.array(lidar_sensor.getRangeImage())
    lidar_ranges = lidar_ranges[80:-80]
    lidar_ranges[lidar_ranges == np.inf] = 100

    # Convert lidar ranges to 2D points in the robot's local coordinate frame
    lidar_points_robot_frame = np.array([
        lidar_ranges * np.cos(lidar_scan_angles_rad) + lidar_x_offset_meters,
        lidar_ranges * np.sin(lidar_scan_angles_rad) + lidar_y_offset_meters,
        np.ones((lidar_active_resolution,)) # Homogeneous coordinate
    ])

    # Transform lidar points from robot frame to world frame
    lidar_points_world_frame = robot_to_world_transform_matrix @ lidar_points_robot_frame

    # Draw robot's current position on the display map
    robot_pixel_x, robot_pixel_y = world_to_map_coordinates(
        robot_x_world, robot_y_world,
        occupancy_grid_map.shape, (WORLD_WIDTH_METERS, WORLD_HEIGHT_METERS)
    )
    robot_display.setColor(0xFF0000) # Red color for robot's path
    robot_display.drawPixel(robot_pixel_x, robot_pixel_y)

    # Iterate through detected obstacle points and update the occupancy grid map
    for obstacle_point_world in lidar_points_world_frame.transpose():
    
        obstacle_pixel_x, obstacle_pixel_y = world_to_map_coordinates(
            obstacle_point_world[0], obstacle_point_world[1],
            occupancy_grid_map.shape, (WORLD_WIDTH_METERS, WORLD_HEIGHT_METERS)
        )
        
        occupancy_grid_map[obstacle_pixel_x, obstacle_pixel_y] += 0.01
        if occupancy_grid_map[obstacle_pixel_x, obstacle_pixel_y] > 1:
            occupancy_grid_map[obstacle_pixel_x, obstacle_pixel_y] = 1

        # Visualize obstacle on display with color indicating certainty
        color_intensity = int(occupancy_grid_map[obstacle_pixel_x, obstacle_pixel_y] * 255)
        
        display_color_rgb = (color_intensity * 256**2 + color_intensity * 256 + color_intensity)
        robot_display.setColor(int(display_color_rgb))
        robot_display.drawPixel(obstacle_pixel_x, obstacle_pixel_y)

    # If the robot has completed two full rounds and is near the final waypoint, stop.
    if (navigation_round_count >= 2) and (distance_to_waypoint < WAYPOINT_PROXIMITY_THRESHOLD):
        print("Robot arrived at final destination!")
        left_motor.setVelocity(0)
        right_motor.setVelocity(0)
        break # Exit the simulation loop

    # Calculate motor speeds based on angle and distance to waypoint
    left_motor_speed = -angle_to_waypoint * ANGULAR_GAIN + distance_to_waypoint * LINEAR_GAIN
    right_motor_speed = angle_to_waypoint * ANGULAR_GAIN + distance_to_waypoint * LINEAR_GAIN

    # Clamp motor speeds to the defined maximum
    left_motor_speed = max(min(MAX_ROBOT_SPEED, left_motor_speed), -MAX_ROBOT_SPEED)
    right_motor_speed = max(min(MAX_ROBOT_SPEED, right_motor_speed), -MAX_ROBOT_SPEED)

    # Set motor velocities
    left_motor.setVelocity(left_motor_speed)
    right_motor.setVelocity(right_motor_speed)

convolved_map = signal.convolve2d(occupancy_grid_map, convolution_kernel, mode='same')

# Display the convolved map. Areas with convolved_map > 0.9 are considered occupied.
plt.imshow(convolved_map > 0.9, origin='lower')
plt.title("Occupancy Grid Map with C-Space (Convolved)")
plt.xlabel("Map X-coordinate (pixels)")
plt.ylabel("Map Y-coordinate (pixels)")
plt.show()